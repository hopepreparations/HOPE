
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS login_username text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS login_password text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS enrollment_status text DEFAULT 'enrolled';
