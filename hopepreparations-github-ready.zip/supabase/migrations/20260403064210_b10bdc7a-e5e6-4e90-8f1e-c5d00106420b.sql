
-- Replace the overly permissive policies with slightly more specific ones
DROP POLICY "Anyone can submit application" ON public.applications;
CREATE POLICY "Anyone can submit application" ON public.applications FOR INSERT WITH CHECK (
  full_name IS NOT NULL AND phone IS NOT NULL AND course IS NOT NULL
);

DROP POLICY "Anyone can submit contact" ON public.contact_messages;
CREATE POLICY "Anyone can submit contact" ON public.contact_messages FOR INSERT WITH CHECK (
  name IS NOT NULL AND phone IS NOT NULL AND message IS NOT NULL
);
